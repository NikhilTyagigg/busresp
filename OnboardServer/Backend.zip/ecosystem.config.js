module.exports = {
    apps: [{
      name: 'onboard',
      script: 'bin/www/', // the path of the script you want to execute,
      // Options reference: https://pm2.keymetrics.io/docs/usage/application-declaration/
    }],
  };