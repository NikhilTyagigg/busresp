var main = {}

main.REDIS_MASTER = {
    USERS: 'p_user',
}

main.MQTT_DATA_SOURCES = {
    USER_MODULE : 1,
    MOBILE_APP : 2,
    WEB_APP : 3
}

module.exports = main