export const utilityConstants = {
    AUTHORIZATION_TOKEN: 'token',
    REFRESH_TOKEN: 'refresh_token',
    SCOPE_PERMISSION_OF_USER: 'scope_permission_of_user',
};