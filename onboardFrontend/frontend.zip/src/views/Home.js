import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  CardText,
  CardLink
} from "reactstrap"

const Home = () => {
  return (
    <div>
      <Card>
        <CardHeader>
          <CardTitle>Profile section to come here</CardTitle>
        </CardHeader>
      </Card>
    </div>
  )
}

export default Home
