const Types = {
    USER: {
      SUCCESS: 'USER/SUCCESS',
    },
    LOGOUT: 'LOGOUT',
  };
  
  export default Types;
  