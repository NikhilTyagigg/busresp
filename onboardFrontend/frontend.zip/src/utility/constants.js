export const LOG_SOURCE={
    1 : 'Mobile App',
    2: 'User Module',
    3: 'Web App'
}