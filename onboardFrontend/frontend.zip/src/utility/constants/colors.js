export const colors = {
    editorGreen: '#43A047',
    white:'#FFFFFF',
    black:'#000000',
    primaryColor: '#1761fd',
    editIconGrey: '#1761fd',
    logoPink: '#ed73b7',
    logoBlue: '#8e8fe2',
    logoPurple: '#a065d8',
    logoMagenta: '#ce71d7',
    logoLightPurple: '#b38be3',
    logoLightPink: '#eb6fdc',
    logoLightMagenta: '#d294d5',
    logoDarkBlue: '#8c8ec4',
    danger: '#DC3545',
    disabled: '#EBEBE4'
}