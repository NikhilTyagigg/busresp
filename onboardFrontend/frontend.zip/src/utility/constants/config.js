export const stripConfig = {
    PUBLISH_KEY: "pk_test_51M9QsrSGQbd3UudFNOBY6630pkjw2AeMUyy8XHyYBPvExUZG7mbll8I0a9zum9K2yINBAoRIVcwzp6jU1ioSni6B00w1JUz066",
}